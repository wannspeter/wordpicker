package com.wordpicker;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;

/**
 * Servlet implementation class wordlist
 */
@WebServlet("/wordlist")
public class wordlist extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public wordlist() {
        super();
    }
	
	//using decrypt() to decrypt word
	public static String decrypt(String strEncrypted,String strKey) throws Exception{
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
			strData=new String(decrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}
	
	//responding to get request
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
String dbkey = "wannspeter";
		
		//testing postgresql driver
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		//Database default access details
		String host1 = "jdbc:postgresql://localhost:8888/";
		String dbName1 = "wordlib";
		String user1  = "worduser";
		String pass1 = "wordpass";
		
		//connecting to database
		Connection conn = null;
		try {
			
			//Checking if webapp database exists	
			conn = DriverManager.getConnection(host1 + dbName1, user1, pass1);
			System.out.println("Connected to db");
		} 
		catch (SQLException e1) {
			
			//Incase it doesn't exist, postgres superuser is used to create it
			//connecting to postgress superuser
			
			//INSERT POSTGRESS SUPERUSER DETAILS HERE
			String host2 = "jdbc:postgresql://localhost:8888/";
			String dbName2 = "postgres";
			String user2  = "postgres"; 
			String pass2 = "wannspeter";
			try {
				conn = DriverManager.getConnection(host2 + dbName2, user2, pass2);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			//Creating new db and user account for new db
			PreparedStatement upd1 = null;
			PreparedStatement upd2 = null;
			try {
				upd1 = conn.prepareStatement("CREATE ROLE worduser PASSWORD 'wordpass' createdb login");
				upd2 = conn.prepareStatement("CREATE DATABASE \"wordlib\" WITH OWNER = worduser  ENCODING = 'UTF8' TABLESPACE = pg_default");
				upd1.executeUpdate();
				upd2.executeUpdate();
			} catch (SQLException e11) {
				e11.printStackTrace();
				System.out.println("Creation failed..");
			}
			
			//Connecting to new db with super user..
			String host3 = "jdbc:postgresql://localhost:8888/";
			String dbName3 = "wordlib";
			String user3  = "postgres";
			String pass3 = "wannspeter";
			try {
				conn = DriverManager.getConnection(host3 + dbName3, user3, pass3);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//Creating pgcrypto extension and tables in new db
			PreparedStatement upd3 = null;
			PreparedStatement upd4 = null;
			PreparedStatement upd5 = null;
			try {
				upd3 = conn.prepareStatement("CREATE EXTENSION IF NOT EXISTS pgcrypto");
				upd4 = conn.prepareStatement("CREATE TABLE IF NOT EXISTS words (hash text, theword bytea, frequency int, CONSTRAINT wordpicker_pkey PRIMARY KEY (hash) )");
				upd5 = conn.prepareStatement("ALTER TABLE public.words OWNER TO worduser;");	
				upd3.executeUpdate();
				upd4.executeUpdate();
				upd5.executeUpdate();
			} catch (SQLException e11) {
				System.out.println("Failed to create pgcrypto extension and table in db..");
				e11.printStackTrace();
			}
			
			//Connecting to new db with new user..
			try {
				conn = DriverManager.getConnection(host1 + dbName1, user1, pass1);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//WEBAPP DATABASE CREATION COMPLETE
		}
		
		//setting response type for front end
		response.setContentType("text/html");
		PrintWriter printWriter  = response.getWriter();
		
		//title of list
		printWriter.println("<br><div style='margin:auto; font-size:18px; font-weight:bold; color:white; text-align:center;'><bold>Showing All Saved Words and Frequency</bold></div><br>");
		
		//creating table
		printWriter.println("<table border='1'  style='margin:auto; color:white; text-align:left;'><tr><th style='width:70%; font-weight:bold;'><b>Word</b></th><th style='width:30%; font-weight:bold;'><b>Frequency</b></th></tr>");
		
		//retrieving from database
		PreparedStatement getwords = null;
		try {
			getwords = conn.prepareStatement("SELECT hash AS hash, pgp_sym_decrypt(theword, '" + dbkey + "') AS theword, frequency AS frequency FROM words ORDER BY frequency DESC");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ResultSet rrows;
		try {
			int count = 0;
			rrows = getwords.executeQuery();
			while(rrows.next()) {
					count = count + 1;
					String hashword1 = rrows.getString(1);
					String theword1 = rrows.getString(2);
					Integer freq1 = rrows.getInt(3);
						
					try {
						
						//adding qoutes to encrypted word to allow decryption
						theword1=theword1.replaceAll("BBB", "'");
						
						//decrypting
						theword1 = decrypt(theword1, hashword1);
						
						//checking for failed decryption
						Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
						java.util.regex.Matcher m = p.matcher(theword1);
						boolean b = m.find();
						
						//Displaying only decrypted words 
						if(!b){
						printWriter.println("<tr><td>" + theword1 + "</td><td>" + freq1 + "</td></tr>");
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			
			//in case no words in db
			if(count==0) {printWriter.println("<tr><td>No words in database</td><td></td></tr>");}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//closing table
		printWriter.println("</table>");
		
		
	}
	
	//responding to post request
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
