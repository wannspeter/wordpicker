package com.pickwords.bot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.security.Key;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.Document;

import org.jsoup.Jsoup;


/**
 * Servlet implementation class pickwords
 */
@WebServlet("/pickwords")
public class pickwords extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public pickwords() {
        super(); 
    }


	//using checkarray() to find string match in array
	public static <T> boolean checkarray(final ArrayList<String> hasharray, final String mytext) {
	    if (mytext == null) {
	        for (final String e : hasharray)
	            if (e == null)
	                return true;
	    } else {
	        for (final String e : hasharray)
	            if (e == mytext || mytext.equals(e))
	                return true;
	    }

	    return false;
	}
	
	//using getElement to get index or position of string in an array
	public int getElement(int[] arrayOfInts, int index) {
	    return arrayOfInts[index];
	}
	
	//using encrypt() to encrypt word
	public static String encrypt(String strClearText,String strKey) throws Exception{
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes());
			strData=new String(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}
	
	//using decrypt() to decrypt word
	public static String decrypt(String strEncrypted,String strKey) throws Exception{
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
			strData=new String(decrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}
	
	//using getSaltString() to generate hash for each word
	public static String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 16) { // length
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }
	
	//using sortByCountValue() to arrange words and frequency in descending order
	public static Map<String, Integer> sortByCountValue(
			Map<String, Integer> mapOfRepeatedWord) {
			Set<Map.Entry<String, Integer>> setOfWordEntries = mapOfRepeatedWord.entrySet(); // get entrySet from HashMap object
			List<Map.Entry<String, Integer>> listOfwordEntry = new ArrayList<Map.Entry<String, Integer>>(setOfWordEntries); // convert HashMap to List of Map entries
			Collections.sort(listOfwordEntry, new Comparator<Map.Entry<String, Integer>>() { // sort list of entries using Collections class utility method sort
			 @Override
			        public int compare(Entry<String, Integer> es1, 
			                Entry<String, Integer> es2) {
			            return es2.getValue().compareTo(es1.getValue());
			        }
			    });
			Map<String, Integer> wordLHMap = new LinkedHashMap<String, Integer>(); // store into LinkedHashMap for maintaining insertion order
			for(Map.Entry<String, Integer> map : listOfwordEntry){ // iterating list and storing in LinkedHahsMap
				wordLHMap.put(map.getKey(), map.getValue());
			}
			return wordLHMap; //result result
			}
		
	//capturing post from front end form
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String dbkey = "wannspeter";
		
		//testing postgresql driver
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		//Database default access details
		String host1 = "jdbc:postgresql://localhost:8888/";
		String dbName1 = "wordlib";
		String user1  = "worduser";
		String pass1 = "wordpass";
		
		//connecting to database
		Connection conn = null;
		try {
			
			//Checking if webapp database exists	
			conn = DriverManager.getConnection(host1 + dbName1, user1, pass1);
			System.out.println("Connected to db");
		} 
		catch (SQLException e1) {
			
			//Incase it doesn't exist, postgres superuser is used to create it
			//connecting to postgress superuser
			
			//INSERT POSTGRESS SUPERUSER DETAILS HERE
			String host2 = "jdbc:postgresql://localhost:8888/";
			String dbName2 = "postgres";
			String user2  = "postgres";
			String pass2 = "wannspeter";
			try {
				conn = DriverManager.getConnection(host2 + dbName2, user2, pass2);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			//Creating new db and user account for new db
			PreparedStatement upd1 = null;
			PreparedStatement upd2 = null;
			try {
				upd1 = conn.prepareStatement("CREATE ROLE worduser PASSWORD 'wordpass' createdb login");
				upd2 = conn.prepareStatement("CREATE DATABASE \"wordlib\" WITH OWNER = worduser  ENCODING = 'UTF8' TABLESPACE = pg_default");
				upd1.executeUpdate();
				upd2.executeUpdate();
			} catch (SQLException e11) {
				e11.printStackTrace();
				System.out.println("Creation failed..");
			}
			
			//Connecting to new db with super user..
			String host3 = "jdbc:postgresql://localhost:8888/";
			String dbName3 = "wordlib";
			String user3  = "postgres";
			String pass3 = "wannspeter";
			try {
				conn = DriverManager.getConnection(host3 + dbName3, user3, pass3);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//Creating pgcrypto extension and tables in new db
			PreparedStatement upd3 = null;
			PreparedStatement upd4 = null;
			PreparedStatement upd5 = null;
			try {
				upd3 = conn.prepareStatement("CREATE EXTENSION IF NOT EXISTS pgcrypto");
				upd4 = conn.prepareStatement("CREATE TABLE IF NOT EXISTS words (hash text, theword bytea, frequency int, CONSTRAINT wordpicker_pkey PRIMARY KEY (hash) )");
				upd5 = conn.prepareStatement("ALTER TABLE public.words OWNER TO worduser;");	
				upd3.executeUpdate();
				upd4.executeUpdate();
				upd5.executeUpdate();
			} catch (SQLException e11) {
				System.out.println("Failed to create pgcrypto extension and table in db..");
				e11.printStackTrace();
			}
			
			//Connecting to new db with new user..
			try {
				conn = DriverManager.getConnection(host1 + dbName1, user1, pass1);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//WEBAPP DATABASE CREATION COMPLETE
		}
		
		
		//capturing url from front end form
		response.setContentType("text/html");
		String myurl=request.getParameter("url"); 
		
		//setting response type for front end
		response.setContentType("text/html");
		PrintWriter printWriter  = response.getWriter();
		
		//Accessing resource
		URL url = new URL(myurl); 
		URLConnection uc = url.openConnection();
		String userPass = "no_username" + ":" + "no_password"; //just in case fields are required, is dummy input feed in
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userPass.getBytes());
		uc.setRequestProperty("Authorization", basicAuth);
		InputStream in = uc.getInputStream();
		BufferedReader reader =  new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8")); //retrieving resource

		 //getting html source code
		String result = "";
		for (String line; (line = reader.readLine()) != null;) {
			result=result.concat(line);
		} 

		//separating content from syntax using jsoup plugin
		org.jsoup.nodes.Document doc = Jsoup.parse(result);
		String result2 = doc.body().text();

		//filtering out common non nouns or verbs
		result2=result2.replaceAll("so ","").replaceAll("these ","").replaceAll("All ","").replaceAll("most ","").replaceAll("old ","").replaceAll("new ","").replaceAll("Hello ","").replaceAll("their ","").replaceAll("more ","").replaceAll("A ","").replaceAll("using ","").replaceAll("after ","").replaceAll("like ","").replaceAll("given ","").replaceAll("used ","").replaceAll("both ","").replaceAll("first ","").replaceAll("While ","").replaceAll("These ","").replaceAll("without ","").replaceAll("needs ","").replaceAll("still ","").replaceAll("do ","").replaceAll("if ","").replaceAll("you ","").replaceAll("went ","").replaceAll("came ","").replaceAll("come ","").replaceAll("some ","").replaceAll("how ","").replaceAll("were ","").replaceAll("other ","").replaceAll("such ","").replaceAll("when ","").replaceAll("than ","").replaceAll("all ","").replaceAll("been ","").replaceAll("have ","").replaceAll("any ","").replaceAll("but ","").replaceAll("also ","").replaceAll("use ","").replaceAll("its ","").replaceAll("has ","").replaceAll("at ","").replaceAll("can ","").replaceAll("which ","").replaceAll("not ","").replaceAll("it ","").replaceAll("or ","").replaceAll("are ","").replaceAll("an ","").replaceAll("as ","").replaceAll("be ","").replaceAll("by ","").replaceAll("on ","").replaceAll("The ","").replaceAll("the ","").replaceAll("that ","").replaceAll("from ","").replaceAll("with ","").replaceAll("the ","").replaceAll("of ","").replaceAll("to ","").replaceAll("and ","").replaceAll("a ","").replaceAll("is ","").replaceAll("in ","").replaceAll("for ","");

		//break content into array of words
		String[] splitArray = result2.split("\\s+"); 
		
		//creating map
		Map<String, Integer> mapOfRepeatedChar = new HashMap<String, Integer>();
		
		//split array to process each word
		for(String words : splitArray) { 
			
			//remove symbols
			Pattern pt = Pattern.compile("[^a-zA-Z0-9]"); 
			Matcher match= pt.matcher(words);
			while(match.find())
			{
				String s= match.group();
				words=words.replaceAll("\\"+s, "");
			}	
			
		//remove numbers	
		words=words.replaceAll("^[\\s\\.\\d]+", "");
		
		//removing spaces
		words=words.replaceAll("\\s+", "");
		
		//if empty, no entry will be made
			if(words!="") { 
				
				//If map contains word, increase count value by 1	
				if(mapOfRepeatedChar.containsKey(words)){
				mapOfRepeatedChar.put(words, mapOfRepeatedChar.get(words) + 1); 
				} 
				
				// otherwise, make a new entry to map
				else {
				mapOfRepeatedChar.put(words, 1); 
				}
			}
		}
		
		//creating arrays using data from database. 
		//This is to avoid a lot of requests to the database for each word during comparison
		ArrayList<String> hasharray  = new ArrayList<String>();
		ArrayList<String> thewordarray  = new ArrayList<String>();
		ArrayList<Integer> freqarray  = new ArrayList<Integer>();

		//retrieving from database
		PreparedStatement getwords = null;
		try {
			getwords = conn.prepareStatement("SELECT hash AS hash, pgp_sym_decrypt(theword, '" + dbkey + "') AS theword, frequency AS frequency FROM words");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rrows;
		try {
			rrows = getwords.executeQuery();
			while(rrows.next()) {
					String hashword1 = rrows.getString(1);
					String theword1 = rrows.getString(2);
					Integer freq1 = rrows.getInt(3);
					
					//decrypting words from database using hash
					try {
						
						//adding qoutes to encrypted word to allow decryption
						theword1=theword1.replaceAll("BBB", "'");
						
						//decrypting
						theword1 = decrypt(theword1, hashword1);
						
						//checking for failed decryption
						Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
						java.util.regex.Matcher m = p.matcher(theword1);
						boolean b = m.find();
						
						//adding only decrypted words to array
						if(!b){
							hasharray.add(hashword1);
							thewordarray.add(theword1);
							freqarray.add(freq1);
						}
						
						} catch (Exception e) {
							e.printStackTrace();
						}			
				}
		} catch (SQLException e1) {
				e1.printStackTrace();
		}
		
		//heading for font end
		printWriter.println("Showing Top 100 words from " + myurl + "<br><br>");
		
		// sort according to descending order
		Map<String, Integer> wordLHMap = sortByCountValue(mapOfRepeatedChar); 
		int count = 0;
		int count2 = 106;
		for(Entry<String, Integer> entry : wordLHMap.entrySet()){
			
			//word count starting
			count = count + 1;
				
			//showing first 100
			if((count<102)&&(count!=1)) { 
				String myword = entry.getKey();
				Integer freq = entry.getValue();
				
				//check if word exists in array
				if(checkarray(thewordarray, myword))
				{
					//using index of array to find hash and frequency
					Integer wordposition = thewordarray.indexOf(myword);
					Integer oldfreq = freqarray.get(wordposition);
					String oldhash = hasharray.get(wordposition);
					
					//adding old and new frequency
					Integer newfreq = oldfreq + freq;
					
					//updating row in database corresponding to hash
					PreparedStatement upd = null;
					try {
						upd = conn.prepareStatement("UPDATE words SET frequency='"+ newfreq +"' WHERE hash='" + oldhash + "' ");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					int j;
					try {
						j = upd.executeUpdate();
						if(j==0) { System.out.println("Not Updated"); }	
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
				//inserting into database if word is not in array
				else
				{
					//getting hash for word
					String salttext = getSaltString();
					
					//encrypting word
					String encrypttext = "";
					try {
					
					//encrypting	
					encrypttext = encrypt(myword, salttext);
					
					//removing quotes from encrypted word to allow inserting in database
					encrypttext=encrypttext.replaceAll("'", "BBB");
					
					//inserting into database
					PreparedStatement ps = conn.prepareStatement("INSERT INTO words (hash, theword, frequency) VALUES ('"+ salttext +"', pgp_sym_encrypt('" + encrypttext + "', '" + dbkey + "'), '" + freq + "') ");
					int i = ps.executeUpdate();
					if(i==0) {System.out.println("Not Saved");}
					} catch (Exception e) {
						e.printStackTrace();
					}	
				}
				
				//reducing font size
				count2 = count2 - 1;
				
				//sending out response to frond end
				printWriter.println("<span style='font-size:"+ count2 +"px;'>" + myword + ",</span>"); 
			}
		}
		
		//incase no words are found
		if((count==0)||(count==1)) {printWriter.println("<span>No words found</span>"); }
	}
	
		//default response for get request
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.getWriter().append("Naughty there").append(request.getContextPath());
	}

		

}
